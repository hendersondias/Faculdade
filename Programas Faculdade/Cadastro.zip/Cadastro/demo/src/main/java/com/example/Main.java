package com.example;

public class Main {
    public static void main(String[] args) {
        Programa programa = new Programa();

        programa.setVisible(true);
    }
}
